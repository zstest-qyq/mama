#!/bin/bash
#my first shell script
#edit by lixiang in 2017-7-31
echo '-----------------------------------------------'
echo "|||||亲爱的用户您好！"
echo "|||||今天是" `date`
json=`curl -s http://www.weather.com.cn/data/sk/101280601.html`
#echo $json
city=`echo $json | sed 's/.*city":"//g'| sed 's/","cityid.*$//g'`
temp=`echo $json | sed 's/.*temp":"//g'| sed 's/","WD.*$//g'`
wd=`echo $json | sed 's/.*WD":"//g'| sed 's/","WS.*$//g'`
ws=`echo $json | sed 's/.*WS":"//g'| sed 's/","SD.*$//g'`
echo '|||||您所在的城市--'$city'的天气情况为:'$temp'℃,'$ws$wd'.'
echo '-----------------------------------------------'

echo '-----------------------------------------------'
echo "|||||亲爱的用户您好！"
echo "|||||今天是" `date`
json=`curl -s http://www.weather.com.cn/data/sk/101300602.html`
#echo $json
city=`echo $json | sed 's/.*city":"//g'| sed 's/","cityid.*$//g'`
temp=`echo $json | sed 's/.*temp":"//g'| sed 's/","WD.*$//g'`
wd=`echo $json | sed 's/.*WD":"//g'| sed 's/","WS.*$//g'`
ws=`echo $json | sed 's/.*WS":"//g'| sed 's/","SD.*$//g'`
echo '|||||您的家乡--'$city'的天气情况为:'$temp'℃,'$ws$wd'.'
echo '-----------------------------------------------'

echo '-----------------------------------------------'
echo "|||||亲爱的用户您好！"
echo "|||||今天是" `date`
json=`curl -s http://www.weather.com.cn/data/sk/101300301.html`
#echo $json
city=`echo $json | sed 's/.*city":"//g'| sed 's/","cityid.*$//g'`
temp=`echo $json | sed 's/.*temp":"//g'| sed 's/","WD.*$//g'`
wd=`echo $json | sed 's/.*WD":"//g'| sed 's/","WS.*$//g'`
ws=`echo $json | sed 's/.*WS":"//g'| sed 's/","SD.*$//g'`
echo '|||||您的母校所在地--'$city'的天气情况为:'$temp'℃,'$ws$wd'.'
echo '-----------------------------------------------'

