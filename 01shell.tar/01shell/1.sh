#!/bin/bash
source ./lib*
read -p "请选择菜单：" n
case $n in
1)#菜单1
menu
read -p "请选择您需要的选项：" a
case $a in
1)
one;;
2)
two;;
3)
three;;
4)
aliyunYUM;;
5)
stp;;
6)
duq;;
7)
break
echo -e "\033[31m您已选择退出\033[0m";;
esac
echo -e "\033[31m操作完成自动,帮您退出...\033[0m"
sleep 1;;
2)#菜单2
menu1
read -p "请选择您需要的选项:" b 
case $b in
1)
mul99;;
2)
echo -ne "\t请输入年: "
            read year

            isYear $year

            case "$?" in
                1) echo -e "\t输入年为空!!" ;;
                2) echo -e "\t输入的不是合法年份!!";;
                3) echo -e "\t不是闰年!!";;
                *) echo -e "\t是闰年!!";;
esac
;;
4)
guess;;
5)
stp;;
6)
cal;;
7)
buy;;
esac
echo -e "\033[31m操作完成自动,帮您退出...\033[0m"
sleep 1;;
esac
