#!/bin/bash
a=100
for((i=$a;i>0;i--))
do
if [ `expr $i % 2` -eq 0 ];then
curl 192.168.43.81/1.html
sleep $1
else
curl 192.168.43.81/1.txt
sleep $1
fi
done
