#!/bin/bash
read -p "请输入分钟:" x
read -p "请输入秒:" y
z=x*60+y
for((time=$z;time>0;time--))
do
a=$[$time/60]
b=$[$time%60]
echo -ne "$a:$b\r"
sleep 1
done

