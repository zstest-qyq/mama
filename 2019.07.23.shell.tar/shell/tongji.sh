#!/bin/bash
read -p "请输入你要统计的路径：" r
a=`ls -l $r |grep "^-"|wc -l`
b=`ls -l $r |grep "^d"|wc -l`
echo "当前目录文件数为$a"
echo "当前目录目录数为$b"

