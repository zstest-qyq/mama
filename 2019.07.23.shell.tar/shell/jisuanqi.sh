#!/bin/bash
echo " ----------------------------------------"
echo "|     简易整数计算器，作者覃永泉        |"
echo " ----------------------------------------"
echo
panduan(){
n=0
while :
do
        read  p
        expr $p + 0 &> /dev/null
        if [ $? -eq 0 ]
        then
                echo "您输入的数是"
                echo $p
                n=$p
                break
        else
                echo "您输入的$p不是整数"
                echo "请输入一个整数："
                continue
        fi
done

}
shuru(){
echo  "请输入第一个整数："
panduan
nu=$n
echo  "请输入第二个整数："
panduan
nu2=$n
}
echo  " ------------------"
echo "|     1.加法       |"
echo "|     2.减法       |"
echo "|     3.乘法       |"
echo "|     4.除法       |"
echo "|     5.求平方     |"
echo "|     6.开平方     |"
echo  " ------------------"
while :
do
read -p "请输入您想执行的算法：" me
case $me in
"1")
shuru
sum=`expr $nu + $nu2`
echo "$nu+$nu2=$sum"
;;
"2")
shuru
jian=`expr $nu - $nu2`
echo "$nu-$nu2=$jian"
;;
"3")
shuru
chen=`expr $nu \* $nu2`
echo "$nu*$nu2=$chen"
;;
"4")
shuru
chu=`expr $nu / $nu2`
echo "$nu/$nu2=$chu"
;;
"5")
echo  "请输入一个整数："
panduan
nu=$n
fang=`expr $nu \* $nu`
echo $nu"的平方等于："$fang
;;
"6")
echo  "请输入一个整数："
panduan
nu=$n
b=$(awk -v x=$nu 'BEGIN{print sqrt(x)}')
echo $b
;;
*)
echo "请选择1、2、3、4"
echo "请重新选择"
esac
done

