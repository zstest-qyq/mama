#!/bin/bash
read -p "请输入数字：" r
i=0
for((i=0;i<$r;i++))
do
echo -ne "$i\r"
sleep 1
done

