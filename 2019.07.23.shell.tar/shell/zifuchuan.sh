#!/bin/bash
read -p "请选择输入：" par
if [ "$par" == "字符串" ];then
        s=`echo $RANDOM|md5sum |cut -c 1-8`
        echo "随机的8位字符串为: $s"
elif [ "$par" == "数字" ];then
        n=`echo $RANDOM|cksum |cut -c 1-8`
        echo "随机的8位数字为: $n"
else
        echo "您的输入有误！";exit 1
fi

