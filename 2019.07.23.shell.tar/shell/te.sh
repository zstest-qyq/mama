#!/bin/bash
ass(){
echo "1"
}
aaa(){
ass
echo "1"
}
aaa

