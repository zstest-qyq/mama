#!/bin/bash
source /05shell/lib
bei(){
	o=$1r`date -d "2 second" +"%Y-%m-%d"`
	p=$1f`date -d "2 second" +"%Y-%m-%d"`
	k=$1r`date -d "2 second" +"%H:%M"`
	m=$1f`date -d "2 second" +"%H:%M"`

	if [ ! -d ./$o ];then
		mkdir ./$o
	fi

	if [ ! -d ./$p ];then
		mkdir ./$p
	fi
	read -p "请输入要练习的单词数：" h
	for((i=1;i<=$h;i++ ))
	do
		echo "第"$i"个"
		n=$((RANDOM % 11 + 1))
		a=$(cat ./chiku |head -n $n |tail -n 1|cut -f$2 -d " ")
		echo $a
		read -p "请作答:" b
		x=$(cat ./chiku|head -n $n |tail -n 1|cut -f$3 -d " ")
	if [ "$b" = "$x" ];then
        	echo "恭喜你答对了！"
        	echo "$x" >> ./$o/$k
	else
        	echo "答错了，很可惜。"
        	echo "$x" >> ./$p/$m

	fi
		echo
	done
	
	r=`cat ./$o/$k|wc -l`
	percent_1=$(printf "%d%%" $(($r*100/$h)))
	echo "你的正确率为："$percent_1
	echo "作答完毕,正在为您跳转。。"
	echo
	sleep 1
	sh $0
	}

echo "------------------------"
echo "1.手敲单词"              
echo "2.看中文写单词"
echo "3.看单词写中文意思"
echo "4.退出"
echo "------------------------"
read -p "请选择菜单：" c
case $c in
1)
bei 1 1 1
;;
2)
bei 2 2 1
;;
3)
bei 3 1 2
;;
4)
break
echo "正在退出..."
jindutiao
esac


