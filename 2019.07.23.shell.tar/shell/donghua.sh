#!/bin/sh
printf -- 'Performing asynchronous action..';
./trigger-action;
DONE=0;
while [ $DONE -eq 0 ]; do
 ./async-checker;
 if [ "$?" = "0" ]; then DONE=1; fi;
 printf -- '.';
 sleep 1;
done;
printf -- ' DONE!\n';
