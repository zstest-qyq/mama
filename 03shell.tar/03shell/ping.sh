#!/bin/bash
. /etc/init.d/functions
read -p "请输入您ping得通的文件名：" n
read -p "请输入您ping得通的文件名：" a
touch /tmp/$n
touch /tmp/$a
chmod 777 /tmp/$n
chmod 777 /tmp/$a
for var in {1..254};
do
ip=192.168.0.$var
ping -c2 $ip >/dev/null 2>&1
if [ $? = 0 ];then
action "$ip" | awk -F " " '{print $1}' >> /tmp/$n
else
action "$ip" | awk -F " " '{print $1}' >>  /tmp/$a
fi
done

